import 'dart:ui';

// Text
Color textPrimary = Color(0xFF111111);
Color textSecondary = Color(0xFF3A3A3A);
